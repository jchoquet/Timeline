<?php
if(isset($_POST['mailform']))

$header="MIME-Version: 1.0\r\n";
$header.='From:"Administrat_Timeline.com"<support@timeline.com>'."\n";
$header.='Content-Type:text/html; charset="uft-8"'."\n";
$header.='Content-Transfer-Encoding: 8bit';

$message='
<html>
	<body>
		<div align="center">
			<br />
			J\'ai envoyé ce mail avec PHP !
			<br />
		</div>
	</body>
</html>
';

mail("primfxtuto@gmail.com", "Salut tout le monde !", $message, $header);
}
?>
<html>
  <head>
  <meta charset="utf-8"/>
  </head>
  <body>
  <h2> formulaire de contact </h2>
<form method="POST" action="">
  <input type="text" name="nom" placeholder="votre nom" />
  <input type="email" name="mail" placeholder="votre email" />
  <textarea name="message" placeholder="votre message"></textarea>
	<input type="submit" value="envoyer !" name="mailform"/>
</form>
</body>
</html>