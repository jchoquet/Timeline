<!DOCTYPE html >
<html lang="fr">
  <head>
    <meta charset="utf-8"/>
    <title>TIMELINE</title>

    <!-- pour les moteurs de recherche -->
    <meta name="description" lang="fr" content="plateforme de timeline photo pour soirée et évènement" />
    <meta name="keywords" lang="fr" content="photos, soirée, timeline, ENSIIE, iiens" />

  <!-- icone du titre de la page -->
  <link rel="shortcut icon" href="fonts/icone2.jpg">


	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- jquery -->
	<script src="js/jquery_library.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.js"></script>

	<!-- fichier css perso -->
	<link rel="stylesheet" href="css/index.css">

	<!-- fichier JS validation formulaire -->
	<script src="js/validate.js"></script>
 
 <style> 
body{ 
margin:0; 
padding:0; 
background: url('fonts/photo1.jpg') no-repeat center fixed;   // changer la photo du fond qui s'adapte � la taille de l'�cran 
-webkit-background-size: cover; /* pour Chrome et Safari */ 
-moz-background-size: cover; /* pour Firefox */ 
-o-background-size: cover; /* pour Opera */ 
background-size: cover; /* version standardis�e */ 
} 
</style> 

</head>
<body >


<div class="container-fluid ">
  
	<div class="tab-content " >
			<form id="co" class="col-md-offset-4 col-md-4 pull-right" role="form">
 				
				<div class="form-group ">
          <div class="thumbnail ">
          <h4><center><FONT face="Segoe Script"> Bienvenue sur TimeLine</FONT></center></h4>
            <p><center><FONT face="Segoe Script">"Cheese, clic & share."</FONT></center></p>
            <img alt="logo" src="fonts/logo.png"/>
            <button class="btn btn-primary btn-block btn-md" type="submit" name="Connexion"><a href="index.php">Se connecter</a></button>
            <button class="btn btn-success btn-block btn-md" type="submit" name="Inscription"><a href="index.php">Inscription</a></button>
          </div>
        </div>    
			</form>
		</div>
   
</div>
</body>
</html>