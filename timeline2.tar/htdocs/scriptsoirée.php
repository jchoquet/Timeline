<?php 
    
    $bdd =  new PDO("mysql:host=127.0.0.1;dbname=db;charset=utf8","root","");  
    if(1==1){    
    $requete = $bdd->prepare("SELECT * FROM Soiree WHERE Annee = :ann AND Theme = :thm")
    $requete ->execute(array(
      'ann'=> $_GET['Annee'],
      'thm'=> $_GET['Theme']
      ));  
      
?>