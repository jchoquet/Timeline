<!DOCTYPE html >
<html lang="fr">
  <head>
    <meta charset="utf-8"/>
    <title>TIMELINE</title>

    <!-- pour les moteurs de recherche -->
    <meta name="description" lang="fr" content="plateforme de timeline photo pour soirée et évènement" />
    <meta name="keywords" lang="fr" content="photos, soirée, timeline, ENSIIE, iiens" />
 
    <!-- icone du titre de la page -->
    <link rel="shortcut icon" href="fonts/icone2.jpg">

	 <!-- jquery -->
	 <script src="jquery_library.js"></script>

	 <!-- Latest compiled and minified JavaScript -->
	 <script src="js/bootstrap.js"></script>

   <!-- Latest compiled and minified CSS -->
   <link rel="stylesheet" href="css/bootstrap.css">
	 <!-- fichier css perso -->
	 <link rel="stylesheet" href="css/base.css">

</head>

<body>

	<!-- barre de navigation -->
     <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="navbar-collapse collapse">
          <ul id="navbar" class="nav navbar-nav">
            <li><a class="navbar-brand" href="#">TIMELINE</a></li>
            <li class="m"><a href="acceuil.php">Accueil</a></li>
            <li><a href="soiree.php">Soirées</a></li>
            <li><a href="concours.php">Concours</a></li>
            <li><a href="ajout.php">Ajout</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>

  <!-- menu gauche -->
	<div id="lmenu" class="container-fluid">
  <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <div class="thumbnail">
            <img alt="profil"  class="img-rounded" src="fonts/im_pro.jpg"/>
            <div class="caption">
              <p>Surnom</p>
            </div>
          </div>
          <ul class="nav nav-sidebar">
            <li><a href="monprofil.php">Mon profil</a></li>
            <li><a href="#">Mes posts</a></li>
            <li><a href="#">Mes identifications</a></li>
            <li><a href="#">Mes wins</a></li>
          </ul>
          <ul class="nav nav-sidebar navbar-static-bottom" id="d">
            <li><a href="#">Déconnexion</a></li>
          </ul>
        </div>
  </div>
  </div>

</body>

</html>

