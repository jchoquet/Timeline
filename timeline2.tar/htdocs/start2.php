<!DOCTYPE html>
<html lang="fr">
  <head>
<meta charset="utf-8"/>
    <title>TIMELINE</title>

    <!-- pour les moteurs de recherche -->
    <meta name="description" lang="fr" content="plateforme de timeline photo pour soirée et évènement" />
    <meta name="keywords" lang="fr" content="photos, soirée, timeline, ENSIIE, iiens" />

  <!-- icone du titre de la page -->
  <link rel="shortcut icon" href="fonts/icone2.jpg">


	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
  <link href="css/docs.css" rel="stylesheet">


	<!-- jquery -->
	<script src="jquery_library.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.js"></script>

	<!-- fichier css perso -->
	<link rel="stylesheet" href="css/index.css">

	<!-- fichier JS validation formulaire -->
	<script src="js/validate.js"></script>
    
  </head>

  <body data-spy="scroll" data-target=".bs-docs-sidebar">

   
<!-- ================================================== -->


<div class="jumbotron masthead">
  <div class="container-fluid">

    <p>
      <div class="tab-content ">
			  <form id="co" class="col-md-offset-4 col-md-4 " role="form">
 				
				  <div class="form-group ">
            <div class="thumbnail ">
            <h4><center><FONT face="Segoe Script"> Bienvenue sur TimeLine</FONT></center></h4>
            <p><center><FONT face="Segoe Script">"Cheese, clic & share."</FONT></center></p>
              <img alt="logo" src="fonts/logo.png"/>
              <button class="btn btn-primary btn-block btn-sm" type="submit" name="Connexion"><a href="index.php">Se connecter</a></button>
              <button class="btn btn-success btn-block btn-sm" type="submit" name="Inscription"><a href="index.php">Inscription</a></button>
          </div>
        </div>    
			</form>
		</div>
    
  </div>
</div>
</div>
</div>
</body>
</html>