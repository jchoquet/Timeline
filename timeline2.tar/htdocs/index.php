<!DOCTYPE html >
<html lang="fr">
  <head>
    <meta charset="utf-8"/>
    <title>TIMELINE</title>

    <!-- pour les moteurs de recherche -->
    <metaname="description" lang="fr" content="plateforme de timeline photo pour soirée et évènement" />
    <metaname="keywords" lang="fr" content="photos, soirée, timeline, ENSIIE, iiens" />

      <!-- icone du titre de la page -->
  <link rel="shortcut icon" href="fonts/icone2.jpg">
     
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- jquery -->
	<script src="js/jquery_library.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.js"></script>

	<!-- fichier css perso -->
	<link rel="stylesheet" href="css/index.css">

    </head>
<body>
<div class="container-fluid ">
  
     <div class="tab-content " >
     <form id="co" class="col-md-offset-4 col-md-4 pull-right" role="form">
 				
     <div class="form-group ">
     <div class="thumbnail ">
     <h4><center> Bienvenue sur TimeLine</center></h4>
     <p><center>"Cheese, clic & share."</center></p>
     <img alt="logo" src="fonts/logo.png"/>
     <button class="btn btn-primary btn-block btn-md" type="submit" name="Connexion"><a href="index.php">Se connecter</a></button>
     <button class="btn btn-success btn-block btn-md" type="submit" name="Inscription"><a href="index.php">Inscription</a></button>
     </div>
     </div>    
     </form>
     </div>
   
</div>
</body>
</html>